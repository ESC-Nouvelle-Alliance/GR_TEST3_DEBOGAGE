﻿/* Gabriel Robinson
* ESC Nouvelle-Alliance, Semestre 2, 2025
* ICS3U Unité 3, Test sommatif (PARTIE PRATIQUE)
* Programme écrit par Mme Northrup (Modifier par Gabriel Robinson)
* 2021-05-14
* 
* Dernière modification: 2025-06-09
*/

/* Ce programme choisit une lettre aléatoire de a à z et demande ensuite à
 * l'utilisateur de deviner cette lettre. 
 */

using System;

namespace GR_ICS3U_TEST3_DEBUG
{
    class Program
    {
      //************************** Méthode Main **********************************
        static void Main(string[] args)
        {
           Console.Title = "Peux-tu deviner la lettre?";

           int n = new Random().Next(0, 25);        //Choisit entre a - z
           char lettre = (char)(97 + n);
           char devinette = ' ';

           Console.WriteLine("Une lettre de l'alphabet est choisie de façon aléatoire.");
           Console.WriteLine("Peux-tu deviner cette lettre? Vous avez 5 essaie à deviner");

            do
            {
                for (int essaie = 1; essaie < 6; essaie++)      //Pour chaque devinette jusqu'a 5
                {
                    Console.Write("\nDevinette: \t");
                    try
                    {
                        devinette = Char.ToLower(char.Parse(Console.ReadLine()));

                        if (devinette == lettre)
                        {
                            Console.WriteLine("\n****************************************************\n");
                            Console.WriteLine("BRAVO! Vous avez deviner la lettre choisie '{0}' en {1} essaie !", lettre, essaie);
                            Console.WriteLine("\n****************************************************\n"); break;
                        }
                        else
                        {
                            if (devinette < 'a' || devinette > 'z')
                            {
                                Console.WriteLine("\nIl faut deviner une lettre de l'alphabet entre a et z.");
                            }
                            else if (devinette > lettre)
                            {
                                Console.WriteLine("\n{1} essaie\nTu n'as pas bien deviné. La lettre choisie PRÉCDÈDE {0}. Devine encore.", devinette, essaie);
                            }
                            else
                            {
                                Console.WriteLine("\n{1} essaie\nTu n'as pas bien deviné. La lettre choisie est APRÈS {0}. Devine encore.", devinette, essaie);
                            }
                        }
                    }

                    catch
                    {
                        Console.WriteLine("\nIl faut choisir une lettre entre a et z.");
                    }

                    if (essaie == 5) 
                    {
                        Console.Clear();
                        
                        Console.WriteLine("Malheureusement, la lettre est {0}", lettre);
                    }

                }
                break;
            } while (devinette != lettre);
              
              Console.WriteLine("Appuie sur la touche ENTER pour terminer.");
              Console.ReadLine();
        }

    }
}
